import pkgutil
import sys

# allowed command tests (please append them alphabetically ordered)
from test_TclCommandAddPolygon import *
from test_TclCommandAddPolyline import *
from test_TclCommandCncjob import *
from test_TclCommandDrillcncjob import *
from test_TclCommandExportGcode import *
from test_TclCommandExteriors import *
from test_TclCommandImportSvg import *
from test_TclCommandInteriors import *
from test_TclCommandIsolate import *
from test_TclCommandNew import *
from test_TclCommandNewGeometry  import *
from test_TclCommandOpenExcellon import *
from test_TclCommandOpenGerber import *
from test_TclCommandPaintPolygon import *
