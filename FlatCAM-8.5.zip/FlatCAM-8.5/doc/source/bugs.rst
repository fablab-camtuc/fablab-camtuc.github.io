Active Bugs
===================

Drill number parsing
--------------------

The screenshot below show the problematic file:

.. image:: drill_parse_problem1.png
   ::align: center

