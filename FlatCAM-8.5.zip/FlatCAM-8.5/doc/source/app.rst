FlatCAM Application
===================

.. automodule:: FlatCAM

App
~~~

.. autoclass:: App
    :members:

PlotCanvas
~~~~~~~~~~

.. autoclass:: PlotCanvas
    :members:

ObjectCollection
~~~~~~~~~~~~~~~~

.. autoclass:: ObjectCollection
    :members:

Measurement
~~~~~~~~~~~

.. autoclass:: Measurement
    :members: