FlatCAM Objects
===============

.. automodule:: FlatCAM

FlatCAMObj
~~~~~~~~~~

.. autoclass:: FlatCAMObj
    :members:

FlatCAMGerber
~~~~~~~~~~~~~

.. autoclass:: FlatCAMGerber
    :members:

FlatCAMExcellon
~~~~~~~~~~~~~~~

.. autoclass:: FlatCAMExcellon
    :members:

FlatCAMCNCjob
~~~~~~~~~~~~~

.. autoclass:: FlatCAMCNCjob
    :members:

FlatCAMGeometry
~~~~~~~~~~~~~~~

.. autoclass:: FlatCAMGeometry
    :members:
